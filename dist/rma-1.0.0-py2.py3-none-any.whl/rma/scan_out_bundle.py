from flask import Blueprint, render_template, request, url_for, flash, redirect
from . import serialize_datetime
from rma.db import get_db
import logging
import json

bp_scan_out = Blueprint('scan_out', __name__, url_prefix='/shipment/scan_out')

def get_product_id(product_sn):
    # Replace this with a function that retrieves the product_id based on product_sn
    # You need to query your database to find the product_id for a given product_sn
    db = get_db()
    result = db.execute('SELECT product_id FROM product WHERE product_sn = ?', (product_sn,))
    product = result.fetchone()
    if product:
        return product['product_id']
    return None 


@bp_scan_out.route('/')
def scan_out():
    db = get_db()
    shipments_out = db.execute(
        'SELECT s.shipment_id, s.type, s.customer_id, p.product_sn, c.customer_name, s.note, s.created_date, s.category_id, cg.category_name, p.product_name '
        'FROM shipment_product sp '
        'JOIN customer c ON s.customer_id = c.customer_id '
        'JOIN category cg ON s.category_id = cg.category_id '
        'JOIN product p ON p.product_id = sp.product_id '
        'JOIN shipment s ON s.shipment_id = sp.shipment_id '
        'WHERE s.type = "出倉" '
        'ORDER BY s.created_date DESC '
    ).fetchall()

    json_results = []
    for shipment_out in shipments_out:
        shipment_out_dict = {
            'shipment_id': shipment_out['shipment_id'],
            'type': shipment_out['type'],
            'category_name': shipment_out['category_name'],            
            'product_sn': shipment_out['product_sn'],
            'customer_name': shipment_out['customer_name'],
            'product_name': shipment_out['product_name'],
            'note': shipment_out['note'],            
            'created_date': serialize_datetime(shipment_out['created_date']),
        }
        json_results.append(shipment_out_dict)

    with open('rma/json/shipments_out.json', 'w') as json_file:
         json.dump(json_results, json_file, default=serialize_datetime)

    return render_template('shipment/scan_out.html', shipments_out = shipments_out )

@bp_scan_out.route('/scan_out_single', methods=('GET', 'POST'))
def scan_out_single():
    customers = None
    db = get_db()

    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_sn = request.form['product_sn']
        note = request.form['note']

        error = None

        if not product_sn:
            error = '請至少輸入一個產品序號'
        if error is not None:
            flash(error)          
        else:
            db = get_db()

            existing_product_query = '''
                SELECT sp.shipment_id 
                FROM shipment_product sp
                JOIN shipment s ON sp.shipment_id = s.shipment_id
                WHERE sp.product_id = (SELECT product_id FROM product WHERE product_sn = ? )
                AND s.type = "出倉"
            '''
            existing_shipment = db.execute(existing_product_query, (product_sn,)).fetchone()

            rma_check_query = '''
                SELECT rma.rma_id 
                FROM rma
                JOIN rma_product rp ON rma.rma_id = rp.rma_id
                WHERE rp.product_id = (SELECT product.product_id FROM product WHERE product.product_sn = ? )
            '''

            has_rma = db.execute(rma_check_query, (product_sn,)).fetchone()

            proceed_with_shipment = False

            if existing_shipment and not has_rma:
                flash(f'產品序號{product_sn}已有出貨紀錄，無法再度出貨')
            elif existing_shipment and has_rma:
                flash(f'產品序號{product_sn}已有出貨紀錄，但因為有RMA紀錄，所以允許再度出貨')
                proceed_with_shipment = True
            else:
                proceed_with_shipment = True

            # If it's okay to proceed with shipment, insert records into the database
            if proceed_with_shipment:
                try:
                    #1st step: insert into shipment table
                    db.execute(
                        'INSERT INTO shipment (customer_id, note, type) VALUES (?, ?, "出倉")',
                        (customer_id, note)
                    )
                    shipment_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]

                    product_id = get_product_id(product_sn)
                    if product_id is not None:
                        #2nd step: insert into shipment_product table
                        db.execute(
                            'INSERT INTO shipment_product (shipment_id, product_id) VALUES (?, ?)',
                            (shipment_id, product_id)
                        )
                    category_query = 'SELECT category_id FROM product WHERE product_id = ?'
                    category_id = db.execute(category_query, (product_id,)).fetchone()[0]

                    #3rd step: update the category_id
                    update_shipment_query = 'UPDATE shipment SET category_id = ? WHERE shipment_id = ?'
                    db.execute(update_shipment_query, (category_id, shipment_id))
                    
                    db.commit()
                    
                    flash('出貨成功')
                except Exception as e:
                    logging.error(f"SQL Error: {e}")
                    db.rollback()

    if customers is None:
        db = get_db()
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()

    return render_template('shipment/scan_out_single.html', customers = customers)


@bp_scan_out.route('/scan_out_batch', methods=('GET', 'POST'))
def scan_out_batch():
    customers = None    

    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_sn_list = request.form.getlist('product_sn[]')  # 取得所有產品序號

        logging.info(f"Received data: customer_id: {customer_id}, product_sn_list: {product_sn_list}")

        error = None

        if not product_sn_list:
            error = '請至少輸入一個產品序號'
        if error is not None:
            flash(error)
        else:
            try:
                db = get_db()

                db.execute(
                    'INSERT INTO shipment (customer_id, type) VALUES (?, "出倉")',
                    (customer_id, )
                )
                shipment_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]  # Get the ID of the newly inserted shipment
                logging.info(f"Inserted shipment with ID: {shipment_id}")

                for product_sn in product_sn_list:
                    product_id = get_product_id(product_sn)
                    if product_id is not None:
                        db.execute(
                            'INSERT INTO shipment_product (shipment_id, product_id) VALUES (?, ?)', 
                            (shipment_id, product_id)
                        )
                        logging.info(f"Inserted product_sn: {product_sn} with product_id: {product_id} into shipment_product")
                        
                        category_query = 'SELECT category_id FROM product WHERE product_id = ?'
                        category_id = db.execute(category_query, (product_id,)).fetchone()[0]
                        
                        update_shipment_query = 'UPDATE shipment SET category_id = ? WHERE shipment_id = ?'
                        db.execute(update_shipment_query, (category_id, shipment_id))

                db.commit()

                return redirect(url_for('overview.scan_out'))

            except Exception as e:
                logging.error(f"SQL Error: {e}")
                db.rollback()

    if customers is None:
        db = get_db()
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()    

    return render_template('shipment/scan_out_batch.html', customers=customers)