from flask import Blueprint, flash, redirect, render_template, request, url_for, jsonify
from rma.auth import login_required
from rma.db import get_db
from rma.customer import bp_customer
from . import serialize_datetime
from datetime import datetime, timedelta
import json
from flask_cors import cross_origin # just for DataTables prevent Cors problem

bp_json = Blueprint('json', __name__, url_prefix='/json')   

@bp_json.route('/product', methods=['GET'])
@cross_origin() 
def get_product_data():
    with open('rma/json/products.json', 'r') as json_file:
        data = json.load(json_file)
    return jsonify(data)

@bp_json.route('/customer', methods=['GET'])
@cross_origin() 
def get_customer_data():
    with open('rma/json/customers.json', 'r') as json_file:
        data = json.load(json_file)
    return jsonify(data)

@bp_json.route('/shipment_in', methods=['GET'])
@cross_origin() 
def get_shipment_data():
    with open('rma/json/shipments_in.json', 'r') as json_file:
        data = json.load(json_file)
    return jsonify(data)

@bp_json.route('/shipment_out', methods=['GET'])
@cross_origin() 
def get_shipment_out_data():
    with open('rma/json/shipments_out.json', 'r') as json_file:
        data = json.load(json_file)
    return jsonify(data)

@bp_json.route('/rma', methods=['GET'])
@cross_origin() 
def get_rma():
    with open('rma/json/rma.json', 'r') as json_file:
        data = json.load(json_file)
    return jsonify(data)

@bp_json.route('/json/product/<product_sn>', methods=['GET'])
def get_product_info(product_sn):
    db = get_db()
    cur = db.cursor()  # Get a cursor object from the connection
    cur.execute("SELECT * FROM product WHERE product_sn = ?", (product_sn,))
    product = cur.fetchone()

    if product:
        # Convert the sqlite3.Row object to a dictionary
        product_dict = {col[0]: product[idx] for idx, col in enumerate(cur.description)}
        return jsonify(product_dict)
    else:
        return jsonify({"error": "Product not found"}), 404

