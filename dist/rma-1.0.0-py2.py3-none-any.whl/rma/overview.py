from flask import Blueprint, flash, redirect, render_template, request, url_for, jsonify
from rma.auth import login_required
from rma.db import get_db
from . import serialize_datetime
from datetime import datetime, timedelta
import json
from flask_cors import cross_origin # just for DataTables prevent Cors problem
import logging

from rma.customer import bp_customer
from rma.json import bp_json
from rma.rma import bp_rma
from rma.product import bp_product
from rma.scan_in_bundle import bp_scan_in
from rma.scan_out_bundle import bp_scan_out
from rma.search import bp_search

bp = Blueprint('overview', __name__)
bp.register_blueprint(bp_customer)
bp.register_blueprint(bp_json)
bp.register_blueprint(bp_rma)
bp.register_blueprint(bp_product)
bp.register_blueprint(bp_scan_in)
bp.register_blueprint(bp_scan_out)
bp.register_blueprint(bp_search)

@bp.route('/')
def index():
    db = get_db()
    products = db.execute(
        'SELECT p.category_id, p.product_name, p.model_name, p.product_sn, p.erp_no, p.ean_code, p.upc_code, p.created_date, cg.category_name'
        ' FROM product p JOIN category cg ON p.category_id = cg.category_id'
        ' ORDER BY created_date DESC LIMIT 5'
    ).fetchall()

    db = get_db()
    customers = db.execute(
        'SELECT c.customer_id, c.customer_name, c.contact, c.type, c.phone, c.email, c.address, c.created_date, c.notes '
        ' FROM customer c'
        ' ORDER BY created_date DESC LIMIT 5'
    ).fetchall() 

    db = get_db()
    shipments = db.execute(
        'SELECT s.shipment_id, s.type, s.customer_id, p.product_sn, c.customer_name, s.note, s.created_date, s.category_id, cg.category_name, p.product_name '
        'FROM shipment_product sp '
        'JOIN customer c ON s.customer_id = c.customer_id '
        'JOIN category cg ON s.category_id = cg.category_id '
        'JOIN product p ON p.product_id = sp.product_id '
        'JOIN shipment s ON s.shipment_id = sp.shipment_id and s.category_id = p.category_id '
        'ORDER BY s.created_date DESC LIMIT 10'
    ).fetchall()  

    return render_template('overviews.html', products = products, customers = customers, shipments = shipments)      

