from flask import Blueprint, flash, redirect, render_template, request, url_for, jsonify
from rma.auth import login_required
from rma.db import get_db
from rma.customer import bp_customer
from . import serialize_datetime
from datetime import datetime, timedelta
import json
from flask_cors import cross_origin # just for DataTables prevent Cors problem
import logging

bp_rma = Blueprint('rma', __name__, url_prefix='/rma')

@bp_rma.route('/')
def rma():
    db = get_db()
    rma = db.execute( 
    '''
    SELECT 
        r.rma_id, r.customer_id, r.status_id, r.request_date, r.resolution_date, r.notes,
        c.customer_id, c.customer_name, c.contact, c.type, c.phone, c.email, c.address, c.created_date, c.notes, 
        p.product_id, p.product_name, p.model_name, p.product_sn, p.erp_no, p.ean_code, p.upc_code, p.created_date,
        rp.return_reason, rp.product_id, rp.rma_id
    FROM RMA r
    JOIN customer c ON c.customer_id = r.customer_id
    JOIN rma_product rp ON r.rma_id = rp.rma_id
    JOIN product p ON p.product_id = rp.product_id
    ORDER BY r.request_date DESC                          
    '''
    ).fetchall()

    json_results = []
    for rma in rma:
        rma_dict = {
            'rma_id': rma['rma_id'],
            'request_date': serialize_datetime(rma['request_date']),            
            'customer_name': rma['customer_name'],
            'product_name': rma['product_name'],            
            'product_sn': rma['product_sn'],
            'return_reason': rma['return_reason'],
        }
        json_results.append(rma_dict)

    with open('rma/json/rma.json', 'w') as json_file:
         json.dump(json_results, json_file, default=serialize_datetime)

    return render_template('rma/index.html', rma = rma )

@bp_rma.route('/rma_create', methods=('GET', 'POST'))
def rma_create():
    customers = None
    rma_statuses = None

    # POST request handler
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_sn = request.form['product_sn']  # Changed from product_id to product_sn
        return_reason = request.form['return_reason']

        error = None

        # Database Operations to get product_id from product_sn
        db = get_db()
        product = db.execute(
            'SELECT product_id FROM product WHERE product_sn = ?',
            (product_sn,)
        ).fetchone()

        # Validation
        if not customer_id or not product:
            error = '請選擇客戶和產品'
        elif not return_reason:
            error = '請填寫退貨原因'

        # Flash error and redirect if any
        if error is not None:
            flash(error)
        else:
            # Inserting into RMA
            db.execute(
                'INSERT INTO rma (customer_id) VALUES (?)',
                (customer_id,)
            )
            rma_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]

            # Inserting into RMA Product
            db.execute(
                'INSERT INTO rma_product (rma_id, product_id, return_reason) VALUES (?, ?, ?)',
                (rma_id, product['product_id'], return_reason)  # product['product_id'] is fetched from product_sn
            )
            db.commit()

            flash('RMA請求已成功提交')
            return redirect(url_for('overview.rma_create'))

    # Handle GET request
    if customers is None:
        db = get_db()
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()
        rma_statuses = db.execute('SELECT status_id, status_name FROM rma_status').fetchall()

    return render_template('rma/create.html', customers=customers, rma_statuses=rma_statuses)
