from flask import Blueprint, flash, redirect, render_template, request, url_for, jsonify
from rma.auth import login_required
from rma.db import get_db
from . import serialize_datetime
from datetime import datetime, timedelta
import json
from flask_cors import cross_origin # just for DataTables prevent Cors problem


bp_product = Blueprint('product', __name__, url_prefix='/products')

@bp_product.route('/')
def products():
    db = get_db()
    products = db.execute('''
        SELECT p.product_id, p.category_id, p.product_name, p.model_name, p.product_sn, p.erp_no, p.ean_code, p.upc_code, created_date, cg.category_name, manufacturing_date
        FROM product p JOIN category cg ON p.category_id = cg.category_id
        ORDER BY created_date DESC
        '''
    ).fetchall()

    json_results = []       
    for product in products:
        product_dict = {
            'product_id': product['product_id'],
            'category_id': product['category_id'],
            'product_name': product['product_name'],
            'model_name': product['model_name'],
            'product_sn': product['product_sn'],
            'erp_no': product['erp_no'],
            'ean_code': product['ean_code'],
            'upc_code': product['upc_code'],
            # 'created_date': product['created_date'],
            'manufacturing_date': serialize_datetime(product['manufacturing_date']),
            'created_date': serialize_datetime(product['created_date']),  
            'category_name': product['category_name']
        }
        json_results.append(product_dict)

    with open('rma/json/products.json', 'w') as json_file:
        # json.dump(json_results, json_file)
         json.dump(json_results, json_file, default=serialize_datetime)

    return render_template('product/index.html', products = products)

# TODO:新增序號檢查

@bp_product.route('/product_create_single', methods=('GET', 'POST'))
def product_create_single():
    categories = None

    if request.method == 'POST':
        category_id = request.form['category_id']
        product_name = request.form['product_name']
        model_name = request.form['model_name']
        erp_no = request.form['erp_no']
        ean_code = request.form['ean_code']
        upc_code = request.form['upc_code']
        product_sn = request.form['product_sn']
        manufacturing_date = request.form['manufacturing_date']

        error = None

        if not product_sn:
            error = '產品序號為必填.'

        if error is not None:
            flash(error)    
        else:
            db = get_db()    

            existing_product_sn_query = 'SELECT product_sn FROM product WHERE product_sn = ?'
            existing_product_sn = db.execute(existing_product_sn_query, (product_sn,)).fetchone()

            if existing_product_sn:
                flash(f'產品序號{product_sn}已存在，無法再次新增')

            else:
                manufacturing_date += " 00:00:00"
                db.execute(
                    'INSERT INTO product (category_id, product_name, model_name, erp_no, product_sn, ean_code, upc_code, manufacturing_date )'
                    ' VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    (category_id, product_name, model_name, erp_no, product_sn, ean_code, upc_code, manufacturing_date)
                )
                db.commit()
                return redirect(url_for('overview.product.products'))
        
    if categories is None:
        db = get_db()
        categories = db.execute('SELECT category_id, category_name FROM category').fetchall()

    return render_template('product/create_single.html', categories=categories)    

@bp_product.route('/product_create_batch_scope', methods=('GET', 'POST'))
def product_create_batch_scope():
    categories = None

    if request.method == 'POST':
        category_id = request.form['category_id']
        product_name = request.form['product_name']
        model_name = request.form['model_name']
        erp_no = request.form['erp_no']
        ean_code = request.form['ean_code']
        upc_code = request.form['upc_code']
        product_sn_prefix = request.form['product_sn_prefix']
        product_sn_range_start = int(request.form['product_sn_range_start'])
        product_sn_range_end = int(request.form['product_sn_range_end'])        

        # 讀取使用者輸入的序號位數
        sn_digit_length = int(request.form['sn_digit_length'])

        error = None

        if product_sn_range_start > product_sn_range_end:
            error = '序號範圍的結束值必須大於或等於序號範圍的起始值'
        elif not product_sn_prefix or product_sn_range_start <= 0 or product_sn_range_end <= 0:
            error = '請填寫完整前綴和序號範圍'
        elif not product_sn_prefix.isalnum():
            existing_product_sn_query = 'SELECT product_sn FROM product WHERE product_sn = ?'
            existing_product_sn = db.execute(existing_product_sn_query, (product_sn,)).fetchone()

            if existing_product_sn:
                flash(f'產品序號{product_sn}已存在，無法再次新增')

        if error is not None:
            flash(error)    
            
        else:
            db = get_db()

            for i in range(product_sn_range_start, product_sn_range_end + 1):
                # product_sn = f'{product_sn_prefix}{i:04d}'  # 根據序號範圍生成帶有前綴的產品序號
                product_sn = f'{product_sn_prefix}{i:0{sn_digit_length}d}'  # 使用使用者指定的序號位數來生成帶有前綴的產品序號
                db.execute(
                    'INSERT INTO product (category_id, product_name, model_name, erp_no, product_sn, ean_code, upc_code )'
                    ' VALUES (?, ?, ?, ?, ?, ?, ?)',
                    (category_id, product_name, model_name, erp_no, product_sn, ean_code, upc_code)
                )

            db.commit()
            return redirect(url_for('overview.product.products'))
        
    if categories is None:
        db = get_db()
        categories = db.execute('SELECT category_id, category_name FROM category').fetchall()

    return render_template('product/create_batch_scope.html', categories=categories)    
