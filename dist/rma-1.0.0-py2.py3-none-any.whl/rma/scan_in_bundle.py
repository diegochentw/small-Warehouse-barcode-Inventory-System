from flask import Blueprint, render_template, request, url_for, flash, redirect
from rma.auth import login_required
from rma.db import get_db
from . import serialize_datetime
import json
import logging

bp_scan_in = Blueprint('scan_in', __name__, url_prefix='/shipment/scan_in')

def get_product_id(product_sn):
    # Replace this with a function that retrieves the product_id based on product_sn
    # You need to query your database to find the product_id for a given product_sn
    db = get_db()
    result = db.execute('SELECT product_id FROM product WHERE product_sn = ?', (product_sn,))
    product = result.fetchone()
    if product:
        return product['product_id']
    return None 


@bp_scan_in.route('/')
def scan_in():
    db = get_db()
    shipments = db.execute(
        'SELECT s.shipment_id, s.type, s.customer_id, p.product_sn, c.customer_name, s.note, s.created_date, s.category_id, cg.category_name, p.product_name '
        'FROM shipment_product sp '
        'JOIN customer c ON s.customer_id = c.customer_id '
        'JOIN category cg ON s.category_id = cg.category_id '
        'JOIN product p ON p.product_id = sp.product_id '
        'JOIN shipment s ON s.shipment_id = sp.shipment_id '
        'WHERE s.type = "進倉" '
        'ORDER BY s.created_date DESC '
    ).fetchall()

    json_results = []
    for shipment in shipments:
        shipment_dict = {
            'shipment_id': shipment['shipment_id'],
            'type': shipment['type'],
            'category_name': shipment['category_name'],            
            'product_sn': shipment['product_sn'],
            'customer_name': shipment['customer_name'],
            'product_name': shipment['product_name'],
            'note': shipment['note'],            
            'created_date': serialize_datetime(shipment['created_date']),
        }
        json_results.append(shipment_dict)

    with open('rma/json/shipments_in.json', 'w') as json_file:
         json.dump(json_results, json_file, default=serialize_datetime)

    return render_template('shipment/scan_in.html', shipments = shipments )

@bp_scan_in.route('/scan_in_single', methods=('GET', 'POST'))
def scan_in_single():
    customers = None    

    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_sn = request.form['product_sn']  # Get a list of product serial numbers
        note = request.form['note']

        logging.info(f"Received data: customer_id: {customer_id}, product_sn: {product_sn}, note: {note}")

        error = None

        if not product_sn:
            error = '請至少輸入一個產品序號'
        if error is not None:
            flash(error)
        else:
            try:
                db = get_db()

                # Check if the product serial number already exists in the shipment_product table
                existing_product_query = 'SELECT shipment_id FROM shipment_product WHERE product_id = (SELECT product_id FROM product WHERE product_sn = ?)'
                existing_shipment = db.execute(existing_product_query, (product_sn,)).fetchone()
                
                if existing_shipment:
                    flash(f'產品序號{product_sn}已有進貨紀錄，無法再度進貨')

                else:

                    # Insert into shipment table first, but without category_id at the beginning
                    db.execute(
                        'INSERT INTO shipment (customer_id, note, type) VALUES (?, ?, "進倉")',
                        (customer_id, note)
                    )
                    shipment_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]  # Get the ID of the newly inserted shipment
                    logging.info(f"Inserted shipment with ID: {shipment_id}")

                    product_id = get_product_id(product_sn)
                    if product_id is not None:
                        # Insert into shipment_product table
                        db.execute(
                            'INSERT INTO shipment_product (shipment_id, product_id) VALUES (?, ?)', 
                            (shipment_id, product_id)
                        )
                        logging.info(f"Inserted product_sn: {product_sn} with product_id: {product_id} into shipment_product")
                        
                        # Fetch category_id based on product_id
                        category_query = 'SELECT category_id FROM product WHERE product_id = ?'
                        category_id = db.execute(category_query, (product_id,)).fetchone()[0]
                        
                        # Now, update the shipment entry with the fetched category_id
                        update_shipment_query = 'UPDATE shipment SET category_id = ? WHERE shipment_id = ?'
                        db.execute(update_shipment_query, (category_id, shipment_id))
                        db.commit()

                    else:
                        logging.warning(f"No matching product_id found for product_sn: {product_sn}")
                        flash('找不到匹配的產品序號')

                    return redirect(url_for('overview.scan_in'))

            except Exception as e:
                logging.error(f"SQL Error: {e}")
                db.rollback()

    if customers is None:
        db = get_db()
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()    

    return render_template('shipment/scan_in_single.html', customers = customers)

# TODO: scan_in_batch

@bp_scan_in.route('/scan_in_batch', methods=('GET', 'POST'))
def scan_in_batch():
    customers = None    

    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_sn_list = request.form.getlist('product_sn[]')  # 取得所有產品序號

        logging.info(f"Received data: customer_id: {customer_id}, product_sn_list: {product_sn_list}")

        error = None

        if not product_sn_list:
            error = '請至少輸入一個產品序號'
        if error is not None:
            flash(error)
        else:
            try:
                db = get_db()

                db.execute(
                    'INSERT INTO shipment (customer_id, type) VALUES (?, "進倉")',
                    (customer_id)
                )
                shipment_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]  # Get the ID of the newly inserted shipment
                logging.info(f"Inserted shipment with ID: {shipment_id}")

                for product_sn in product_sn_list:
                    product_id = get_product_id(product_sn)
                    if product_id is not None:
                        db.execute(
                            'INSERT INTO shipment_product (shipment_id, product_id) VALUES (?, ?)', 
                            (shipment_id, product_id)
                        )
                        logging.info(f"Inserted product_sn: {product_sn} with product_id: {product_id} into shipment_product")
                        
                        category_query = 'SELECT category_id FROM product WHERE product_id = ?'
                        category_id = db.execute(category_query, (product_id,)).fetchone()[0]
                        
                        update_shipment_query = 'UPDATE shipment SET category_id = ? WHERE shipment_id = ?'
                        db.execute(update_shipment_query, (category_id, shipment_id))

                db.commit()

                return redirect(url_for('overview.scan_in'))

            except Exception as e:
                logging.error(f"SQL Error: {e}")
                db.rollback()

    if customers is None:
        db = get_db()
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()    

    return render_template('shipment/scan_in_batch.html', customers = customers)

# TODO: scan_in_range

def generate_serial_numbers(start_sn, end_sn):
    start_alpha = ''.join(filter(str.isalpha, start_sn))
    start_num = ''.join(filter(str.isdigit, start_sn))
    
    end_alpha = ''.join(filter(str.isalpha, end_sn))
    end_num = ''.join(filter(str.isdigit, end_sn))
    
    if start_alpha != end_alpha:
        raise ValueError("英文字母部分不相同.")
    
    return [
        start_alpha + str(i).zfill(len(start_num))
        for i in range(int(start_num), int(end_num) + 1)
    ]

import time

@bp_scan_in.route('/scan_in_range', methods=('GET', 'POST'))
def scan_in_range():
    customers = None
    
    if request.method == 'POST':
        start_time = time.time()  # Start timestamp
        
        customer_id = request.form['customer_id']
        start_product_sn = request.form['start_product_sn']
        end_product_sn = request.form['end_product_sn']

        try:
            product_sn_list = generate_serial_numbers(start_product_sn, end_product_sn)
        except ValueError as ve:
            flash(str(ve))
            return render_template('shipment/scan_in_range.html', customers=customers)

        logging.info(f"Time taken to generate serial numbers: {time.time() - start_time:.2f} seconds.")
        logging.info(f"Received data: customer_id: {customer_id}, product_sn_list: {product_sn_list}")

        error = None
        if not product_sn_list:
            error = '請至少輸入一個產品序號'
        
        if error is not None:
            flash(error)
        else:
            db_start_time = time.time()  # DB operations start timestamp
            try:
                db = get_db()

                # Insert shipment
                db.execute('INSERT INTO shipment (customer_id, type) VALUES (?, "進倉")', (customer_id,))
                shipment_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
                logging.info(f"Inserted shipment with ID: {shipment_id}")

                # Get product IDs in bulk
                product_ids = {sn: get_product_id(sn) for sn in product_sn_list}
                logging.info(f"Time taken to get product IDs: {time.time() - db_start_time:.2f} seconds.")

                # Batch insert for shipment_product
                data_to_insert = [(shipment_id, product_ids[sn]) for sn in product_sn_list if product_ids[sn] is not None]
                db.executemany('INSERT INTO shipment_product (shipment_id, product_id) VALUES (?, ?)', data_to_insert)

                # Get category_ids in bulk
                category_start_time = time.time()  # Category fetch start timestamp
                product_ids_values = list(filter(None, product_ids.values()))
                category_query = 'SELECT product_id, category_id FROM product WHERE product_id IN ({})'.format(', '.join(['?']*len(product_ids_values)))
                categories = db.execute(category_query, product_ids_values).fetchall()
                logging.info(f"Time taken to get categories: {time.time() - category_start_time:.2f} seconds.")
                category_mapping = {row[0]: row[1] for row in categories}

                # Update shipment with category_id
                for product_id in product_ids_values:
                    update_shipment_query = 'UPDATE shipment SET category_id = ? WHERE shipment_id = ?'
                    db.execute(update_shipment_query, (category_mapping[product_id], shipment_id))

                db.commit()
                logging.info(f"Total DB operations time: {time.time() - db_start_time:.2f} seconds.")
                return redirect(url_for('overview.scan_in'))

            except Exception as e:
                logging.error(f"SQL Error: {e}")
                db.rollback()

    if customers is None:
        db = get_db()
        fetch_start_time = time.time()  # Customer fetch start timestamp
        customers = db.execute('SELECT customer_id, customer_name FROM customer').fetchall()
        logging.info(f"Time taken to fetch customers: {time.time() - fetch_start_time:.2f} seconds.")    

    return render_template('shipment/scan_in_range.html', customers=customers)

